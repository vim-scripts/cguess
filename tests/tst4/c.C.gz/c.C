namespace {
	namespace {
		char a;
	}
}

namespace {
	namespace {
		char a;
	}
}
